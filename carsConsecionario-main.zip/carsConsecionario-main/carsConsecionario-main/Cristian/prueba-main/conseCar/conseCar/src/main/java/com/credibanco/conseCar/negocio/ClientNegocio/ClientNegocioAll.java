package com.credibanco.conseCar.negocio.ClientNegocio;
import com.credibanco.conseCar.dto.VentaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import java.util.List;
@Component
public class ClientNegocioAll {
    @Autowired
    private   ClientNegocioAll clientNegocioAll;


    public List<VentaDTO>encontrarTodasVentas(){
        return clientNegocioAll.encontrarTodasVentas();
    }


}

