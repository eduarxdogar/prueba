package com.credibanco.conseCar.entities.empleadoImplService;

import com.credibanco.conseCar.dto.ClienteDTO;
import com.credibanco.conseCar.entities.Cliente;
import com.credibanco.conseCar.repositories.IClienteRepository;
import com.credibanco.conseCar.service.Iempeladoservice.IEmpleadoServiceById;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

@Service
public class EmpleadoById implements IEmpleadoServiceById {

    private final IClienteRepository iClienteRepository;

    @Autowired
    public EmpleadoById(IClienteRepository iClienteRepository) {
        this.iClienteRepository = iClienteRepository;
    }

    @Override
    public ClienteDTO encontrarporId(Long id) {
        // Utilizamos el método findById del repositorio para buscar el cliente por su ID
        Optional<Cliente> cliente = iClienteRepository.findById(id);

        // Utilizamos el método orElseThrow para lanzar una excepción si el cliente no se encuentra
        Cliente clienteEncontrado = cliente.orElseThrow(()-> new EntityNotFoundException("Cliente no encontrado"));


        // Utilizamos el método mapToDto para convertir el objeto Cliente en un objeto ClienteDTO
        ClienteDTO clienteDTO= mapToDto(clienteEncontrado);

        return clienteDTO;

    }
    private ClienteDTO mapToDto(Cliente cliente){
        ClienteDTO clienteDTO = new ClienteDTO();

        clienteDTO.setId(cliente.getId());
        clienteDTO.setNombre(cliente.getNombre());
        clienteDTO.setApellido(cliente.getApellido());
        clienteDTO.setTelefonoPersonal(cliente.getTelefonoPersonal());
        clienteDTO.setDireccion(cliente.getDireccion());
        return clienteDTO;
    }
}
