package com.credibanco.conseCar.service.Iempeladoservice;

import com.credibanco.conseCar.dto.ClienteDTO;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface IEmpleadoServiceAll {

    List<ClienteDTO> encontrarTodos();
}
