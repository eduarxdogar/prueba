package com.credibanco.conseCar.implemetacion.consecionarioImplService;

import com.credibanco.conseCar.dto.EmpleadoDTO;
import com.credibanco.conseCar.entities.Empleado;
import com.credibanco.conseCar.repositories.IEmpleadoRepository;
import com.credibanco.conseCar.service.Iconsecionarioservice.IConsecionarioServiceUpdate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

@Service
public class ConsecionarioUpdate implements IConsecionarioServiceUpdate {

    private final IEmpleadoRepository iEmpleadoRepository;
    @Autowired
    public ConsecionarioUpdate(IEmpleadoRepository iEmpleadoRepository) {
        this.iEmpleadoRepository = iEmpleadoRepository;
    }

    @Override
    public void actualizarEmpelado(EmpleadoDTO empleadoDTO) {
        Optional<Empleado> empleadoExistente = iEmpleadoRepository.findById(empleadoDTO.getId());


        empleadoExistente.ifPresentOrElse(
                c ->{
                    c.setId(empleadoDTO.getId());
                    c.setNombre(empleadoDTO.getNombre());
                    c.setApellido(empleadoDTO.getApellido());
                    c.setCorreoCorporativo(empleadoDTO.getCorreoCorporativo());
                    c.setTelCorporativo(empleadoDTO.getTelCorporativo());

                    iEmpleadoRepository.save(c);
                },()->{
                    throw new EntityNotFoundException("Cliente no encontrado ");
                }
        );

    }
}
