package com.credibanco.conseCar.service.Iconsecionarioservice;

import com.credibanco.conseCar.dto.EmpleadoDTO;

public interface IConsecionarioServiceById {

    public EmpleadoDTO encontrarporId(Long Id);

}
