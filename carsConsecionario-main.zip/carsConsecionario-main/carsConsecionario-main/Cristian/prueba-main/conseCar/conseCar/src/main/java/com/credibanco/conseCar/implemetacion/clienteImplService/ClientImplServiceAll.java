package com.credibanco.conseCar.implemetacion.clienteImplService;

import com.credibanco.conseCar.dto.VentaDTO;
import com.credibanco.conseCar.entities.Venta;
import com.credibanco.conseCar.repositories.IVentaRepository;
import com.credibanco.conseCar.service.Iclientservice.IClientServiceAll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClientImplServiceAll implements IClientServiceAll {

    private final IVentaRepository iVentaRepository;

    @Autowired
    public ClientImplServiceAll(IVentaRepository iVentaRepository) {
        this.iVentaRepository = iVentaRepository;
    }

    @Override
    public List<VentaDTO> encontrarTodasVentas() {

        List<Venta> ventaList = iVentaRepository.findAll();

        if (ventaList.isEmpty()) {
            throw new EntityNotFoundException("No se encontraron clientes");
        }

        List<VentaDTO> ventaDTOS = ventaList.stream()
                .map(venta -> mapToDto(venta))
                .collect(Collectors.toList());

        return ventaDTOS;
    }
    private VentaDTO mapToDto(Venta venta){
        VentaDTO ventaDTO = new VentaDTO();

        ventaDTO.setId(venta.getId());
        ventaDTO.setPrecioVenta(venta.getPrecioVenta());
        ventaDTO.setPuntosAcomulados(venta.getPuntosAcumulados());
        return ventaDTO;
    }
}
