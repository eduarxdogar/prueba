package com.credibanco.conseCar.negocio.consecionarioNegocio;

public class ConsecionarioNegocio {
}
