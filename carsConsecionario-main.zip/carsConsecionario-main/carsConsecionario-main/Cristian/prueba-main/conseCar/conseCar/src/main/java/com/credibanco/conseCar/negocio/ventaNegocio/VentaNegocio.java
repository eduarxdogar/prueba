package com.credibanco.conseCar.negocio.ventaNegocio;

public class VentaNegocio {
}
