package com.credibanco.conseCar.service.Iconsecionarioservice;

import com.credibanco.conseCar.dto.EmpleadoDTO;

public interface IConsecionarioServiceCreate {
    void crearEmpleado(EmpleadoDTO empleadoDTO);
}
