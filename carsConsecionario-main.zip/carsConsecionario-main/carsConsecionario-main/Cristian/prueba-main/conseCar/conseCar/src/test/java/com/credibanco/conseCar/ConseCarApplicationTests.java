package com.credibanco.conseCar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConseCarApplicationTests {

	@Test
	void contextLoads() {

	}

}
