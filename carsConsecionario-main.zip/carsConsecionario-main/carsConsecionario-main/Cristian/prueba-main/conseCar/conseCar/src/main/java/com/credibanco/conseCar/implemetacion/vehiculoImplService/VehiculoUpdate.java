package com.credibanco.conseCar.implemetacion.vehiculoImplService;

import com.credibanco.conseCar.dto.VehiculoDTO;
import com.credibanco.conseCar.entities.Vehiculo;
import com.credibanco.conseCar.repositories.IConsecionarioRepository;
import com.credibanco.conseCar.service.Ivehiculoservice.IVehiculoServiceUpdate;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;


public class VehiculoUpdate implements IVehiculoServiceUpdate {

    private final IConsecionarioRepository iConsecionarioRepository;

    @Autowired
    public VehiculoUpdate(IConsecionarioRepository iConsecionarioRepository) {
        this.iConsecionarioRepository = iConsecionarioRepository;
    }

    @Override
    public List<VehiculoDTO> actualizarVehiculo(VehiculoDTO vehiculoDTO) {
        // Obtener el vehículo actual de la base de datos
        Optional<VehiculoDTO> optionalVehiculoDTO = iConsecionarioRepository.encontrarVehiculoPorId(vehiculoDTO.getConcesionarioId(), vehiculoDTO.getId());

        if (optionalVehiculoDTO.isPresent()) {
            VehiculoDTO vehiculoDTOResult = optionalVehiculoDTO.get();

            // Aquí necesitarías convertir tu VehiculoDTO a un Vehiculo.
            Vehiculo vehiculo = convertirDtoAVehiculo(vehiculoDTOResult);

            iConsecionarioRepository.actualizarVehiculo(vehiculo);

            Optional<Vehiculo> optionalVehiculo = Optional.of(vehiculo);
        } else {
            Optional<Vehiculo> optionalVehiculo = Optional.empty();
        }
       return iConsecionarioRepository.encontrarTodosVehiculos();
    }

    private VehiculoDTO convertirDtoAVehiculo(Vehiculo vehiculo) {
        VehiculoDTO vehiculoDTO = new VehiculoDTO();

        vehiculoDTO.setId(vehiculo.getId());
        vehiculoDTO.setTipo(vehiculo.getTipo());
        vehiculoDTO.setModelo(vehiculoDTO.getModelo());
        vehiculoDTO.setPrecioUsado(vehiculoDTO.getPrecioUsado());
        vehiculoDTO.setPrecioNuevo(vehiculoDTO.getPrecioNuevo());
        vehiculoDTO.setAnoFabricacion(vehiculoDTO.getAnoFabricacion());

        return vehiculoDTO;

    }

}

