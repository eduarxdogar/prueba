package com.credibanco.conseCar.implemetacion.consecionarioImplService;

import com.credibanco.conseCar.dto.EmpleadoDTO;
import com.credibanco.conseCar.entities.Empleado;
import com.credibanco.conseCar.repositories.IEmpleadoRepository;
import com.credibanco.conseCar.service.Iconsecionarioservice.IconsecionarioServiceAll;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;
@Service
public class ConsecionarioAll implements IconsecionarioServiceAll {

    private final IEmpleadoRepository iEmpleadoRepository;
    @Autowired
    public ConsecionarioAll(IEmpleadoRepository iEmpleadoRepository) {
        this.iEmpleadoRepository = iEmpleadoRepository;
    }


    @Override
    public List<EmpleadoDTO> encontrarTodosEmpleados() {

        List<Empleado> empleadoList = iEmpleadoRepository.findAll();

        if (empleadoList.isEmpty()){
            throw new EntityNotFoundException(" No se encontraron Empleados");
        }

        List<EmpleadoDTO> empleadoDTOList = empleadoList.stream()
                .map(empleado -> mapToDto(empleado))
                .collect(Collectors.toList());

        return empleadoDTOList;
    }

    private EmpleadoDTO mapToDto (Empleado empleado) {
        EmpleadoDTO empleadoDTO = new EmpleadoDTO();

        empleadoDTO.setId(empleado.getId());
        empleadoDTO.setNombre(empleado.getNombre());
        empleadoDTO.setApellido(empleado.getApellido());
        empleadoDTO.setCorreoCorporativo(empleado.getCorreoCorporativo());
        empleadoDTO.setTelCorporativo(empleado.getTelCorporativo());

        return empleadoDTO;
    }

}

