package com.credibanco.conseCar.service.Ivehiculoservice;

import org.springframework.stereotype.Service;

@Service
public interface IVehiculoServiceDelete {

    void eliminarVehiculo(Long vehiculoId);

}
