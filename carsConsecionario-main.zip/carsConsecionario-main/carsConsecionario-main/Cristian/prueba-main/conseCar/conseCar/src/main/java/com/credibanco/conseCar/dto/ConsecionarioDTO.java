package com.credibanco.conseCar.dto;

import lombok.Data;

@Data
public class ConsecionarioDTO {

    private  Long id;

    private  String nombre;

    private String direccion;

    @Override
    public String toString() {
        return "ConsecionarioDTO{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", direccion='" + direccion + '\'' +
                '}';
    }
}
