package com.credibanco.conseCar.implemetacion.consecionarioImplService;

import com.credibanco.conseCar.dto.EmpleadoDTO;
import com.credibanco.conseCar.entities.Empleado;
import com.credibanco.conseCar.repositories.IEmpleadoRepository;
import com.credibanco.conseCar.service.Iconsecionarioservice.IConsecionarioServiceById;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;
@Service
public class ConsecionarioById implements IConsecionarioServiceById {

    private final IEmpleadoRepository iEmpleadoRepository;
    @Autowired
    public ConsecionarioById(IEmpleadoRepository iEmpleadoRepository) {
        this.iEmpleadoRepository = iEmpleadoRepository;
    }

    @Override
    public EmpleadoDTO encontrarporId(Long Id) {

        Optional<Empleado> empleado = iEmpleadoRepository.findById(Id);

        Empleado empleadoEcontrado = empleado.orElseThrow(() -> new EntityNotFoundException());

        EmpleadoDTO empleadoDTO = mapToDto(empleadoEcontrado);

        return empleadoDTO;
    }

    private EmpleadoDTO mapToDto(Empleado empleado){
        EmpleadoDTO empleadoDTO = new EmpleadoDTO();

        empleadoDTO.setId(empleado.getId());
        empleadoDTO.setNombre(empleado.getNombre());
        empleadoDTO.setApellido(empleado.getApellido());
        empleadoDTO.setCorreoCorporativo(empleado.getCorreoCorporativo());
        empleadoDTO.setTelCorporativo(empleadoDTO.getTelCorporativo());


        return empleadoDTO;
    }


}
