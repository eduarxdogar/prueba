package com.credibanco.conseCar.service.Ivehiculoservice;


import com.credibanco.conseCar.dto.VehiculoDTO;
import org.springframework.stereotype.Service;


import java.util.List;
@Service
public interface IVehiculoServiceAll {
    List<VehiculoDTO> encontrarTodosVehiculos();
}
