package com.credibanco.conseCar.entities.empleadoImplService;

import com.credibanco.conseCar.dto.ClienteDTO;
import com.credibanco.conseCar.entities.Cliente;
import com.credibanco.conseCar.repositories.IClienteRepository;
import com.credibanco.conseCar.service.Iempeladoservice.IEmpleadoServiceUpdate;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

public class EmpleadoUpdate implements IEmpleadoServiceUpdate {

    private  final IClienteRepository iClienteRepository;

   @Autowired
    public EmpleadoUpdate(IClienteRepository iClienteRepository) {
        this.iClienteRepository = iClienteRepository;
    }

    @Override
    public void actualizarCliente(ClienteDTO clienteDTO) {
        // Utilizamos el método findById del repositorio para buscar el cliente por su ID
        Optional<Cliente> clienteExistente = iClienteRepository.findById(clienteDTO.getId());

        // Utilizamos el método ifPresentOrElse para actualizar el cliente si existe o lanzar una excepción si no existe
        clienteExistente.ifPresentOrElse(
                c ->{
                    // Mapeamos los valores del DTO al cliente existente
                    c.setNombre(clienteDTO.getNombre());
                    c.setApellido(clienteDTO.getApellido());
                    c.setDireccion(clienteDTO.getDireccion());
                    c.setTelefonoPersonal(clienteDTO.getTelefonoPersonal());
                    c.setId(clienteDTO.getId());

                    // Guardamos los cambios en el repositorio
                    iClienteRepository.save(c);
                },()-> {
                    throw new EntityNotFoundException("Cliente no encontrado ");
                }
        );

    }
}
