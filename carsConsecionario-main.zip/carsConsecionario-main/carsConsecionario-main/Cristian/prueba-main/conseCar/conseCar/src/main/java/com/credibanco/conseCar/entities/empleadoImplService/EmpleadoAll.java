package com.credibanco.conseCar.entities.empleadoImplService;

import com.credibanco.conseCar.dto.ClienteDTO;
import com.credibanco.conseCar.entities.Cliente;
import com.credibanco.conseCar.repositories.IClienteRepository;
import com.credibanco.conseCar.service.Iempeladoservice.IEmpleadoServiceAll;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

public class EmpleadoAll implements IEmpleadoServiceAll {

    private final IClienteRepository iClienteRepository;

    public EmpleadoAll(IClienteRepository iClienteRepository) {
        this.iClienteRepository = iClienteRepository;
    }

    @Override
    public List<ClienteDTO> encontrarTodos() {
        // Utilizamos el método findAll del repositorio para obtener una lista de clientes
        List<Cliente> clientes = iClienteRepository.findAll();

        // Verificamos si la lista de clientes está vacía
        if (clientes.isEmpty()) {
            // Si la lista está vacía, lanzamos una excepción
            throw new EntityNotFoundException("No se encontraron clientes");
        }

        // Utilizamos una expresión lambda para convertir cada objeto Cliente en un objeto ClienteDTO
        List<ClienteDTO> clienteDTOs = clientes.stream()
                .map(cliente -> mapToDto(cliente))
                .collect(Collectors.toList());

        // Devolvemos la lista de objetos ClienteDTO
        return clienteDTOs;
    }
    private ClienteDTO mapToDto(Cliente cliente){
        ClienteDTO clienteDTO = new ClienteDTO();

        clienteDTO.setId(cliente.getId());
        clienteDTO.setNombre(cliente.getNombre());
        clienteDTO.setApellido(cliente.getApellido());
        clienteDTO.setTelefonoPersonal(cliente.getTelefonoPersonal());
        clienteDTO.setDireccion(cliente.getDireccion());
        return clienteDTO;
    }

}
