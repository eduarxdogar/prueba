package com.credibanco.conseCar.implemetacion.consecionarioImplService;

import com.credibanco.conseCar.dto.EmpleadoDTO;
import com.credibanco.conseCar.entities.Empleado;
import com.credibanco.conseCar.repositories.IEmpleadoRepository;
import com.credibanco.conseCar.service.Iconsecionarioservice.IConsecionarioServiceCreate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConsecionarioCreate implements IConsecionarioServiceCreate {

    private final IEmpleadoRepository iEmpleadoRepository;
    @Autowired
    public ConsecionarioCreate(IEmpleadoRepository iEmpleadoRepository) {
        this.iEmpleadoRepository = iEmpleadoRepository;
    }

    @Override
    public void crearEmpleado(EmpleadoDTO empleadoDTO) {

        Empleado empleado = mapToEntity (empleadoDTO);

        iEmpleadoRepository.save(empleado);

    }

    private Empleado mapToEntity(EmpleadoDTO empleadoDTO) {
        Empleado empleado = new Empleado();

        empleado.setId(empleadoDTO.getId());
        empleado.setNombre(empleadoDTO.getNombre());
        empleado.setApellido(empleadoDTO.getApellido());
        empleado.setCorreoCorporativo(empleadoDTO.getCorreoCorporativo());
        empleado.setTelCorporativo(empleadoDTO.getTelCorporativo());
        return empleado;
    }

}
