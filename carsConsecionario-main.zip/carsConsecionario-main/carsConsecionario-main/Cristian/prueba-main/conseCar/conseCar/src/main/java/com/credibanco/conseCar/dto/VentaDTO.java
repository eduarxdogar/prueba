package com.credibanco.conseCar.dto;

import lombok.Data;

@Data
public class VentaDTO {

    private Long id;

    private double precioVenta;


    private int puntosAcomulados;


}
