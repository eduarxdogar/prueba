package com.credibanco.conseCar.service.Iconsecionarioservice;

public interface IConsecionarioServiceDelete {
    void eliminarEmpleado(Long id);
}
