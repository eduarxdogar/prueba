package com.credibanco.conseCar.negocio.empleadoNegocio;

public class EmpleadoNegocio {
}
