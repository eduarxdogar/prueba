package com.credibanco.conseCar.service.Iclientservice;

import com.credibanco.conseCar.dto.VentaDTO;

import java.util.List;

public interface IClientUpdateService {
    List<VentaDTO> actualizarVentas(VentaDTO ventaDTO);
}
