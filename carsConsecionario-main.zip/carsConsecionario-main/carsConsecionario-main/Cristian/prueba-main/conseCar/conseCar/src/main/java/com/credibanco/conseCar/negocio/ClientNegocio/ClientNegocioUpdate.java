package com.credibanco.conseCar.negocio.ClientNegocio;

import com.credibanco.conseCar.dto.VentaDTO;
import com.credibanco.conseCar.implemetacion.clienteImplService.ClienteImplServiceUpdate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ClientNegocioUpdate {

    private final ClienteImplServiceUpdate clienteImplServiceUpdate;

    @Autowired
    public ClientNegocioUpdate(ClienteImplServiceUpdate clienteImplServiceUpdate) {
        this.clienteImplServiceUpdate = clienteImplServiceUpdate;
    }

    public List<VentaDTO> actualizarVentas(VentaDTO ventaDTO) {
        return clienteImplServiceUpdate.actualizarVentas(ventaDTO);
    }

}
