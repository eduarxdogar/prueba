package com.credibanco.conseCar.service.Iclientservice;

import com.credibanco.conseCar.dto.VentaDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IClientServiceAll {

    List<VentaDTO>encontrarTodasVentas();



}
