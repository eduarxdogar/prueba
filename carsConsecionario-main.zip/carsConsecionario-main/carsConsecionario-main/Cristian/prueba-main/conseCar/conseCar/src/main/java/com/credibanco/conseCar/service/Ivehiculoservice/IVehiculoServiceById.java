package com.credibanco.conseCar.service.Ivehiculoservice;


import com.credibanco.conseCar.dto.VehiculoDTO;
import org.springframework.stereotype.Service;

@Service
public interface IVehiculoServiceById {
    VehiculoDTO encontrarVehiculoPorId(Long concesionarioId, Long vehiculoId);
}
