package com.credibanco.conseCar.service.Iconsecionarioservice;

import com.credibanco.conseCar.dto.EmpleadoDTO;
import com.credibanco.conseCar.dto.VehiculoDTO;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface IConsecionarioServiceUpdate {








    void actualizarEmpelado(EmpleadoDTO empleadoDTO);






}
