package com.credibanco.conseCar.service.Ivehiculoservice;

import com.credibanco.conseCar.dto.VehiculoDTO;
import com.credibanco.conseCar.entities.Vehiculo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface IVehiculoServiceUpdate {
    List<VehiculoDTO> actualizarVehiculo(VehiculoDTO vehiculoDTO);

}
