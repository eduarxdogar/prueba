package com.credibanco.conseCar.entities.empleadoImplService;

import com.credibanco.conseCar.dto.ClienteDTO;
import com.credibanco.conseCar.entities.Cliente;
import com.credibanco.conseCar.repositories.IClienteRepository;
import com.credibanco.conseCar.service.Iempeladoservice.IEmpleadoServiceCreate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpleadoCreate implements IEmpleadoServiceCreate {

   private final IClienteRepository iClienteRepository;

    @Autowired
    public EmpleadoCreate(IClienteRepository iClienteRepository) {
        this.iClienteRepository = iClienteRepository;
    }

    @Override
    public void crearCliente(ClienteDTO clienteDTO) {
        // Utilizamos el método mapToEntity para convertir el objeto ClienteDTO en un objeto Cliente
        Cliente cliente = mapToEntity(clienteDTO);

        // Utilizamos el método save del repositorio para guardar el objeto Cliente en la base de datos
        iClienteRepository.save(cliente);

    }

    private Cliente mapToEntity(ClienteDTO clienteDTO) {
        Cliente cliente = new Cliente();

        cliente.setId(clienteDTO.getId());
        cliente.setNombre(clienteDTO.getNombre());
        cliente.setApellido(clienteDTO.getApellido());
        cliente.setTelefonoPersonal(clienteDTO.getTelefonoPersonal());
        cliente.setDireccion(clienteDTO.getDireccion());

        return cliente;
    }
}
