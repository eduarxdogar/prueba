package com.credibanco.conseCar.implemetacion.vehiculoImplService;

import com.credibanco.conseCar.dto.VehiculoDTO;
import com.credibanco.conseCar.entities.Vehiculo;
import com.credibanco.conseCar.repositories.IConsecionarioRepository;
import com.credibanco.conseCar.service.Ivehiculoservice.IVehiculoServiceCreate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehiculoCreate implements IVehiculoServiceCreate {

    private final IConsecionarioRepository iConsecionarioRepository;

    @Autowired
    public VehiculoCreate(IConsecionarioRepository iConsecionarioRepository) {
        this.iConsecionarioRepository = iConsecionarioRepository;
    }

    @Override
    public void crearVehiculo(VehiculoDTO vehiculoDTO) {

    }

    private VehiculoDTO mapToDto(Vehiculo vehiculo) {
        VehiculoDTO vehiculoDTO = new VehiculoDTO();

        vehiculoDTO.setId(vehiculo.getId());
        vehiculoDTO.setTipo(vehiculo.getTipo());
        vehiculoDTO.setModelo(vehiculo.getModelo());
        vehiculoDTO.setPrecioUsado(vehiculo.getPrecioUsado());
        vehiculoDTO.setPrecioNuevo(vehiculo.getPrecioNuevo());
        vehiculoDTO.setAnoFabricacion(vehiculo.getAnoFabricacion());

        return vehiculoDTO;
    }
}