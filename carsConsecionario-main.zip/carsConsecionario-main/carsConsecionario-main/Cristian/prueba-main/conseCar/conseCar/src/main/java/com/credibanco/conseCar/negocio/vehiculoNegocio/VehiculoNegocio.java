package com.credibanco.conseCar.negocio.vehiculoNegocio;

public class VehiculoNegocio {
}
