package com.credibanco.conseCar.repositories;

import com.credibanco.conseCar.dto.VehiculoDTO;
import com.credibanco.conseCar.dto.VentaDTO;
import com.credibanco.conseCar.entities.Consecionario;
import com.credibanco.conseCar.entities.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IConsecionarioRepository extends JpaRepository<Consecionario, Long> {
     @Query("SELECT v FROM Consecionario c JOIN c.vehiculos v WHERE c.id = :concesionarioId AND v.id = :vehiculoId")
     Optional<VehiculoDTO> encontrarVehiculoPorId(Long concesionarioId, Long vehiculoId);


     @Query("SELECT v FROM Consecionario c JOIN c.vehiculos v WHERE c.id = :concesionarioId")
     List<Vehiculo> encontrarTodosVehiculos();

     @Modifying
     @Query("DELETE Vehiculo v WHERE v.id = :vehiculoId")
     void eliminarVehiculo(Long vehiculoId);

     @Modifying
     @Query("UPDATE Vehiculo v SET v.tipo = :tipo, v.modelo = :modelo, v.precioUsado = :precioUsado, v.precioNuevo = :precioNuevo, v.anoFabricacion = :anoFabricacion WHERE v.id = :vehiculoId")
     Vehiculo actualizarVehiculo(Long vehiculoId, String tipo, String modelo, Double precioUsado, Double precioNuevo, Integer anoFabricacion);
}


