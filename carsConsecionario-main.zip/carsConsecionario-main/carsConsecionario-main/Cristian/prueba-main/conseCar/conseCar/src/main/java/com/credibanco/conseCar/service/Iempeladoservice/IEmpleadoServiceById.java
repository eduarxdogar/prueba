package com.credibanco.conseCar.service.Iempeladoservice;

import com.credibanco.conseCar.dto.ClienteDTO;
import org.springframework.stereotype.Service;

@Service
public interface IEmpleadoServiceById {
    public ClienteDTO encontrarporId(Long Id);
}
