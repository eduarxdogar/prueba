package com.credibanco.conseCar.service.Iempeladoservice;

import org.springframework.stereotype.Service;

@Service
public interface IEmpleadoServiceDelete {
    void eliminarCliente(Long id);

}
