package com.credibanco.conseCar.entities.empleadoImplService;

import com.credibanco.conseCar.repositories.IClienteRepository;
import com.credibanco.conseCar.service.Iempeladoservice.IEmpleadoServiceDelete;
import org.springframework.beans.factory.annotation.Autowired;

public class EmpleadoDelete implements IEmpleadoServiceDelete {

    private  final IClienteRepository iClienteRepository;

    @Autowired
    public EmpleadoDelete(IClienteRepository iClienteRepository) {
        this.iClienteRepository = iClienteRepository;
    }

    @Override
    public void eliminarCliente(Long id) {
        // Utilizamos el método deleteById del repositorio
        iClienteRepository.deleteById(id);
    }
}
