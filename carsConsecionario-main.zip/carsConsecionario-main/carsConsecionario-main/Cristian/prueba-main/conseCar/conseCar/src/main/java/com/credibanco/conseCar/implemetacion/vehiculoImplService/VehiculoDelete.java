package com.credibanco.conseCar.implemetacion.vehiculoImplService;

public class VehiculoDelete {
}
