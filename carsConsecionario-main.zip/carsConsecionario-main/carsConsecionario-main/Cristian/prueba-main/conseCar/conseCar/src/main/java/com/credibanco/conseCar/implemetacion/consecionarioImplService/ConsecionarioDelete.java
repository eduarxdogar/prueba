package com.credibanco.conseCar.implemetacion.consecionarioImplService;

import com.credibanco.conseCar.repositories.IEmpleadoRepository;
import com.credibanco.conseCar.service.Iconsecionarioservice.IConsecionarioServiceDelete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConsecionarioDelete implements IConsecionarioServiceDelete {

    private final IEmpleadoRepository iEmpleadoRepository;
    @Autowired
    public ConsecionarioDelete(IEmpleadoRepository iEmpleadoRepository) {
        this.iEmpleadoRepository = iEmpleadoRepository;
    }

    @Override
    public void eliminarEmpleado(Long id) {
        iEmpleadoRepository.deleteById(id);

    }
}
