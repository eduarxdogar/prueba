package com.credibanco.conseCar.implemetacion.vehiculoImplService;

import com.credibanco.conseCar.dto.VehiculoDTO;
import com.credibanco.conseCar.entities.Vehiculo;
import com.credibanco.conseCar.repositories.IConsecionarioRepository;
import com.credibanco.conseCar.service.Ivehiculoservice.IVehiculoServiceById;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;

@Service
public class VehiculoById implements IVehiculoServiceById {

    private  final IConsecionarioRepository iConsecionarioRepository;

    @Autowired
    public VehiculoById(IConsecionarioRepository iConsecionarioRepository) {
        this.iConsecionarioRepository = iConsecionarioRepository;
    }

    @Override
    public VehiculoDTO encontrarVehiculoPorId(Long concesionarioId, Long vehiculoId) {
        Vehiculo vehiculo = iConsecionarioRepository.encontrarVehiculoPorId(concesionarioId, vehiculoId)
                .orElseThrow(() -> new EntityNotFoundException("Vehículo no encontrado"));

        return mapToDto(vehiculo);
    }
    private VehiculoDTO mapToDto(Vehiculo vehiculo){
        VehiculoDTO vehiculoDTO = new VehiculoDTO();

        vehiculoDTO.setId(vehiculo.getId());
        vehiculoDTO.setTipo(vehiculo.getTipo());
        vehiculoDTO.setModelo(vehiculo.getModelo());
        vehiculoDTO.setPrecioUsado(vehiculo.getPrecioUsado());
        vehiculoDTO.setPrecioNuevo(vehiculo.getPrecioNuevo());
        vehiculoDTO.setAnoFabricacion(vehiculo.getAnoFabricacion());

        return vehiculoDTO;
    }
}
