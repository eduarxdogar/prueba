package com.credibanco.conseCar.service.Iconsecionarioservice;

import com.credibanco.conseCar.dto.EmpleadoDTO;
import com.credibanco.conseCar.dto.VehiculoDTO;

import java.util.List;

public interface IconsecionarioServiceAll {
    List<EmpleadoDTO> encontrarTodosEmpleados();


}
