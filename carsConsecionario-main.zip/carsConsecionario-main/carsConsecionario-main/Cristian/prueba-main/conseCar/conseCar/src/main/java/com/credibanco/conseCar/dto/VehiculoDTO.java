package com.credibanco.conseCar.dto;

import lombok.Data;



@Data
public class VehiculoDTO {

    private Long concesionarioId;

    private Long id;

    private String tipo;

    private String modelo;

    private int anoFabricacion;

    private double precioNuevo;

    private double precioUsado;
}
